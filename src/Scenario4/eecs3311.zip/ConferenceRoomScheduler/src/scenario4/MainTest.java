package scenario4;

public class MainTest {

    public static void main(String[] args) {

        AdminManager manager = new AdminManager();

        manager.addRoom("ENG101", "Lassonde", 50);
        manager.addRoom("ENG102", "Lassonde", 70);

        System.out.println("\nAll rooms:");
        for (Room r : manager.getAllRooms()) {
            System.out.println(r);
        }
    }
}
