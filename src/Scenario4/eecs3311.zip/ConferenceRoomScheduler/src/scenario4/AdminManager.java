package scenario4;

import java.util.List;

public class AdminManager {
    private RoomRepository repo = RoomRepository.getInstance();

    public void addRoom(String id, String building, int capacity) {
        Room room = AdminFactory.createRoom(id, building, capacity);
        repo.addRoom(room);
        System.out.println("Room added: " + room);
    }

    public List<Room> getAllRooms() {
        return repo.getAllRooms();
    }
}
