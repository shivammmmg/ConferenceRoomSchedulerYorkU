package scenario4;

import javax.swing.*;
import java.awt.*;

public class AddRoomFrame extends JFrame {

    public AddRoomFrame(AdminManager manager) {
        setTitle("Add Room");
        setSize(300, 200);
        setLayout(new GridLayout(4, 2, 10, 10));

        JLabel idLbl = new JLabel("Room ID:");
        JTextField idField = new JTextField();

        JLabel buildingLbl = new JLabel("Building:");
        JTextField buildingField = new JTextField();

        JLabel capLbl = new JLabel("Capacity:");
        JTextField capField = new JTextField();

        JButton saveBtn = new JButton("Save");

        saveBtn.addActionListener(e -> {
            try {
                String id = idField.getText();
                String building = buildingField.getText();
                int capacity = Integer.parseInt(capField.getText());
                manager.addRoom(id, building, capacity);

                JOptionPane.showMessageDialog(this, "Room added!");
                dispose();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input!");
            }
        });

        add(idLbl); add(idField);
        add(buildingLbl); add(buildingField);
        add(capLbl); add(capField);
        add(new JLabel()); add(saveBtn);

        setVisible(true);
    }
}
