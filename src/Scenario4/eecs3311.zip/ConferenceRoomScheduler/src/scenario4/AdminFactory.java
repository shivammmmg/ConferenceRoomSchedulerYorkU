package scenario4;

public class AdminFactory {

    public static Room createRoom(String id, String building, int capacity) {
        return new Room(id, building, capacity);
    }
}
