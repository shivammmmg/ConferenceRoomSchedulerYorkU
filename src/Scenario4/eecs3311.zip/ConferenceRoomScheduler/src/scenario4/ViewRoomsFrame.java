package scenario4;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ViewRoomsFrame extends JFrame {

    public ViewRoomsFrame(AdminManager manager) {
        setTitle("All Rooms");
        setSize(400, 300);
        setLayout(new BorderLayout());

        JTextArea area = new JTextArea();

        List<Room> rooms = manager.getAllRooms();
        for (Room r : rooms) {
            area.append(r.toString() + "\n");
        }

        add(new JScrollPane(area), BorderLayout.CENTER);

        setVisible(true);
    }
}
