package scenario4;

import javax.swing.*;
import java.awt.*;

public class ManageRoomFrame extends JFrame {

    public ManageRoomFrame(AdminManager manager) {

        setTitle("Manage Room");
        setSize(300, 250);
        setLayout(new GridLayout(4, 2, 10, 10));

        JLabel idLbl = new JLabel("Room ID:");
        JTextField idField = new JTextField();

        JButton enableBtn = new JButton("Enable Room");
        JButton disableBtn = new JButton("Disable Room");
        JButton maintenanceBtn = new JButton("Schedule Maintenance");

        enableBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                    "Room " + idField.getText() + " Enabled!");
        });

        disableBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                    "Room " + idField.getText() + " Disabled!");
        });

        maintenanceBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                    "Maintenance Scheduled for Room " + idField.getText());
        });

        add(idLbl); add(idField);
        add(enableBtn); 
        add(disableBtn);
        add(maintenanceBtn);

        setVisible(true);
    }
}
