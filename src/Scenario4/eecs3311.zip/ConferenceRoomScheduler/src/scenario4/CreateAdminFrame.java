package scenario4;

import javax.swing.*;
import java.awt.*;

public class CreateAdminFrame extends JFrame {

    public CreateAdminFrame(AdminManager manager) {

        setTitle("Create Admin Account");
        setSize(300, 200);
        setLayout(new GridLayout(3, 2, 10, 10));

        JLabel nameLbl = new JLabel("Name:");
        JTextField nameField = new JTextField();

        JLabel emailLbl = new JLabel("Email:");
        JTextField emailField = new JTextField();

        JButton createBtn = new JButton("Create");

        createBtn.addActionListener(e -> {
            String name = nameField.getText();
            String email = emailField.getText();

            // you can store admin later — for now, just display
            JOptionPane.showMessageDialog(this,
                    "Admin Created:\nName: " + name + "\nEmail: " + email);

            dispose();
        });

        add(nameLbl); add(nameField);
        add(emailLbl); add(emailField);
        add(new JLabel()); add(createBtn);

        setVisible(true);
    }
}
