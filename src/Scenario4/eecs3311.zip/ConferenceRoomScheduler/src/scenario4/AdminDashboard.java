package scenario4;

import javax.swing.*;
import java.awt.*;

public class AdminDashboard extends JFrame {

    private AdminManager manager = new AdminManager();

    public AdminDashboard() {

        // Window settings
        setTitle("Admin Dashboard");
        setSize(450, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // center screen
        setLayout(new BorderLayout());

        // HEADER PANEL
        JPanel header = new JPanel();
        header.setBackground(new Color(52, 152, 219)); // blue
        JLabel title = new JLabel("Conference Room Admin Panel");
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        header.add(title);

        // BUTTON PANEL
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 1, 15, 15));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        buttonPanel.setBackground(new Color(236, 240, 241)); // light grey

        // Create modern buttons
        JButton addRoomBtn = createButton("Add Room");
        JButton viewRoomsBtn = createButton("View Rooms");
        JButton createAdminBtn = createButton("Create Admin");
        JButton manageRoomBtn = createButton("Manage Rooms");

        addRoomBtn.addActionListener(e -> new AddRoomFrame(manager));
        viewRoomsBtn.addActionListener(e -> new ViewRoomsFrame(manager));
        createAdminBtn.addActionListener(e -> new CreateAdminFrame(manager));
        manageRoomBtn.addActionListener(e -> new ManageRoomFrame(manager));

        buttonPanel.add(addRoomBtn);
        buttonPanel.add(viewRoomsBtn);
        buttonPanel.add(createAdminBtn);
        buttonPanel.add(manageRoomBtn);

        // ADD PANELS TO WINDOW
        add(header, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    // 🔹 Helper method to create modern buttons
    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 16));
        btn.setBackground(new Color(41, 128, 185)); // blue
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminDashboard::new);
    }
}
