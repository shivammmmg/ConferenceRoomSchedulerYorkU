package scenario4;

public class Room {
    private String roomId;
    private String building;
    private int capacity;

    public Room(String roomId, String building, int capacity) {
        this.roomId = roomId;
        this.building = building;
        this.capacity = capacity;
    }

    public String getRoomId() { return roomId; }
    public String getBuilding() { return building; }
    public int getCapacity() { return capacity; }

    @Override
    public String toString() {
        return roomId + " - " + building + " (" + capacity + " seats)";
    }
}
